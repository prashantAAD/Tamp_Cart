package com.example.tampcart.tampcart.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;

import android.os.Bundle;


import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.tampcart.databinding.ActivityMainBinding;
import com.example.tampcart.tampcart.adapters.CategoryAdapter;
import com.example.tampcart.tampcart.adapters.ProductAdapter;
import com.example.tampcart.tampcart.models.Category;
import com.example.tampcart.tampcart.models.Product;
import com.example.tampcart.tampcart.utils.Constants;

import org.imaginativeworld.whynotimagecarousel.model.CarouselItem;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
ActivityMainBinding binding;
CategoryAdapter categoryAdapter;
ArrayList<Category>categories;
ProductAdapter productAdapter;
ArrayList<Product> products;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

       initCategories();
       initProducts();
       initSlider();
    }

    private void initSlider() {
        binding.carousel.addData(new CarouselItem("https://cdn.pixabay.com/photo/2017/02/13/08/54/brain-2062057_960_720.jpg","hello alien"));
        binding.carousel.addData(new CarouselItem("https://cdn.pixabay.com/photo/2017/02/13/08/54/brain-2062057_960_720.jpg","hello alien"));
        binding.carousel.addData(new CarouselItem("https://cdn.pixabay.com/photo/2017/02/13/08/54/brain-2062057_960_720.jpg","hello alien"));
        binding.carousel.addData(new CarouselItem("https://cdn.pixabay.com/photo/2017/02/13/08/54/brain-2062057_960_720.jpg","hello alien"));
    }


    void initCategories(){
        categories=new ArrayList<>();
        categories.add(new Category("maulik","https://cdn.pixabay.com/photo/2017/02/13/08/54/brain-2062057_960_720.jpg","#FF03DAC5","description",1));
        categories.add(new Category("maulik","https://cdn.pixabay.com/photo/2017/02/13/08/54/brain-2062057_960_720.jpg","#FF03DAC5","description",1));
        categories.add(new Category("maulik","https://cdn.pixabay.com/photo/2017/02/13/08/54/brain-2062057_960_720.jpg","#FF03DAC5","description",1));
        categories.add(new Category("maulik","https://cdn.pixabay.com/photo/2017/02/13/08/54/brain-2062057_960_720.jpg","#FF03DAC5","description",1));
        categories.add(new Category("maulik","https://cdn.pixabay.com/photo/2017/02/13/08/54/brain-2062057_960_720.jpg","#FF03DAC5","description",1));
        categories.add(new Category("maulik","https://cdn.pixabay.com/photo/2017/02/13/08/54/brain-2062057_960_720.jpg","#FF03DAC5","description",1));
        categories.add(new Category("maulik","https://cdn.pixabay.com/photo/2017/02/13/08/54/brain-2062057_960_720.jpg","#FF03DAC5","description",1));
        categories.add(new Category("maulik","https://cdn.pixabay.com/photo/2017/02/13/08/54/brain-2062057_960_720.jpg","#FF03DAC5","description",1));
        categoryAdapter=new CategoryAdapter(this,categories);

        getCategories();

        GridLayoutManager layoutManager=new GridLayoutManager(this,4);
        binding.categoriesList.setLayoutManager(layoutManager);
        binding.categoriesList.setAdapter(categoryAdapter);
    }
    void getCategories(){
        // Instantiate the RequestQueue.
        RequestQueue queue = Volley.newRequestQueue(this);
        // Request a string response from the provided URL.
        StringRequest stringRequest = new StringRequest(Request.Method.GET, Constants.GET_CATEGORIES_URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject mainobj=new JSONObject(response);
                    if (mainobj)
                } catch (JSONException e) {
                    throw new RuntimeException(e);
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }

    });
        queue.add(stringRequest);
    }

    void initProducts(){
        products=new ArrayList<>();
        productAdapter=new ProductAdapter(this,products);
        products.add(new Product("aarav","https://cdn.pixabay.com/photo/2017/02/13/08/54/brain-2062057_960_720.jpg","",12,12,1,1));
        products.add(new Product("aarav","https://cdn.pixabay.com/photo/2017/02/13/08/54/brain-2062057_960_720.jpg","",12,12,1,1));
        products.add(new Product("aarav","https://cdn.pixabay.com/photo/2017/02/13/08/54/brain-2062057_960_720.jpg","",12,12,1,1));
        products.add(new Product("aarav","https://cdn.pixabay.com/photo/2017/02/13/08/54/brain-2062057_960_720.jpg","",12,12,1,1));
        products.add(new Product("aarav","https://cdn.pixabay.com/photo/2017/02/13/08/54/brain-2062057_960_720.jpg","",12,12,1,1));
        products.add(new Product("aarav","https://cdn.pixabay.com/photo/2017/02/13/08/54/brain-2062057_960_720.jpg","",12,12,1,1));
        products.add(new Product("aarav","https://cdn.pixabay.com/photo/2017/02/13/08/54/brain-2062057_960_720.jpg","",12,12,1,1));
        products.add(new Product("aarav","https://cdn.pixabay.com/photo/2017/02/13/08/54/brain-2062057_960_720.jpg","",12,12,1,1));
        products.add(new Product("aarav","https://cdn.pixabay.com/photo/2017/02/13/08/54/brain-2062057_960_720.jpg","",12,12,1,1));
        products.add(new Product("aarav","https://cdn.pixabay.com/photo/2017/02/13/08/54/brain-2062057_960_720.jpg","",12,12,1,1));
        products.add(new Product("aarav","https://cdn.pixabay.com/photo/2017/02/13/08/54/brain-2062057_960_720.jpg","",12,12,1,1));
        products.add(new Product("aarav","https://cdn.pixabay.com/photo/2017/02/13/08/54/brain-2062057_960_720.jpg","",12,12,1,1));
        products.add(new Product("aarav","https://cdn.pixabay.com/photo/2017/02/13/08/54/brain-2062057_960_720.jpg","",12,12,1,1));
        products.add(new Product("aarav","https://cdn.pixabay.com/photo/2017/02/13/08/54/brain-2062057_960_720.jpg","",12,12,1,1));
        products.add(new Product("aarav","https://cdn.pixabay.com/photo/2017/02/13/08/54/brain-2062057_960_720.jpg","",12,12,1,1));
        products.add(new Product("aarav","https://cdn.pixabay.com/photo/2017/02/13/08/54/brain-2062057_960_720.jpg","",12,12,1,1));


        GridLayoutManager layoutManager=new GridLayoutManager(this,2);
        binding.productList.setLayoutManager(layoutManager);
        binding.productList.setAdapter(productAdapter);
    }
}